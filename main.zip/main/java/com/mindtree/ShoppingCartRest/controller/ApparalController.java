package com.mindtree.ShoppingCartRest.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShoppingCartRest.entity.Apparal;
import com.mindtree.ShoppingCartRest.exception.ApparalAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.service.ProductService;

import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author M1053638
 *
 */
@RestController

@Api(value = "Shopping Cart apparal", description = "Apparal CRUD Operation")
@RequestMapping(value = "/apparal")
public class ApparalController {

	@Autowired
	private ProductService productService;

	private static final Logger logger = LoggerFactory.getLogger(ApparalController.class);
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public boolean addApparal(@RequestBody Apparal apparaldetail) {
		boolean flag = false;
		String success = null;
		try {
			success = productService.addApparalToDb(apparaldetail);
			flag = true;
			return flag;
		} catch (ApparalAlreadyExist e) {
			logger.error("Apparal Already Exist");
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		} finally {
			if (flag) {
				logger.info(success);
			}
		}
		return flag;
	}
	@RequestMapping(value = "/displayApparal", method = RequestMethod.GET)
	public List<Apparal> displayAllApparal() {
		List<Apparal> list1 = null;
		try {
			list1 = productService.displayAllApparals();
		}

		catch (ResourceNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return list1;
	}

	@RequestMapping(value = "/updateApparal/{apparalId}", method = RequestMethod.PUT)
	public Apparal updateApparal(@PathVariable int apparalId, @RequestBody Apparal apparal) {
		try {
			return productService.updateApparalDetail(apparalId, apparal);
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}
		return null;
	}

	@RequestMapping(value = "/deleteApparal", method = RequestMethod.DELETE)
	public boolean deleteApparal(int apparalId) {
		boolean flag = false;
		try {
			if (productService.deleteApparalDetail(apparalId)) {
				flag = true;
			}
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}

		return flag;
	}
}
	
	
	

