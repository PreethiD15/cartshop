package com.mindtree.ShoppingCartRest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShoppingCartRest.entity.Book;
import com.mindtree.ShoppingCartRest.exception.BookAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.service.ProductService;

import io.swagger.annotations.Api;

/**
 * @author M1053638
 *
 */
@RestController
@RequestMapping(value = "/book")
@Api(value = "Shopping Cart book", description = "Book CRUD Operation")
public class BookController {

	@Autowired
	private ProductService productService;

	private static final Logger logger = LoggerFactory.getLogger(BookController.class);

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public boolean addBook(@RequestBody Book bookdetail) {
		boolean flag = false;
		String success = null;
		try {
			success = productService.addBookToDb(bookdetail);
			flag = true;
			return flag;
		} catch (BookAlreadyExist e) {
			logger.error("Book Already Exist");
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		} finally {
			if (flag) {
				logger.info(success);
			}
		}
		return flag;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public List<Book> displayAllBook() {
		List<Book> list1 = null;
		try {
			list1 = productService.displayAllBooks();
		}

		catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		}
		return list1;
	}

	@RequestMapping(value = "/update/{bookId}", method = RequestMethod.PUT)
	public Book updateBook(@PathVariable int bookId, @RequestBody Book book) {
		try {
			return productService.updateBookDetail(bookId, book);
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}
		return null;
	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public boolean deleteBook(int bookId) {
		boolean flag = false;
		try {
			if (productService.deleteBookDetail(bookId)) {
				flag = true;
			}
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}

		return flag;
	}

}
