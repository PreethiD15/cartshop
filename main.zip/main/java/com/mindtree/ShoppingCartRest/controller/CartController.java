package com.mindtree.ShoppingCartRest.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShoppingCartRest.entity.Cart;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserNotFoundException;

import com.mindtree.ShoppingCartRest.service.CartService;


/**
 * @author M1053638
 *
 */
@RestController
@RequestMapping(value = "/cart")
public class CartController {
	@Autowired
	private CartService cartService;
	@RequestMapping(value = "/user/{userId}/product/{productId}", method = RequestMethod.PUT)
	public String addProductIncart(@PathVariable int userId,@PathVariable int productId)
	{ 
		try {
			return cartService.addProductTocart(userId,productId);
		}
		catch(UserNotFoundException e)
		{
			System.out.println("User is not in Database");
		}
		catch(ProductNotFoundException e)
		{
			System.out.println("Product is not in Database");
		}
		return null;
		
	}
	@RequestMapping(value = "/user/{userId}/product/{productId}/quantity/{quantityId}", method = RequestMethod.PUT)
	public Cart removeProductIncart(@PathVariable int userId,@PathVariable int productId,@PathVariable int quantityId)
	{
		try {
			try {
				return cartService.removeProductTocart(userId,productId,quantityId);
			} catch (ResourceNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		catch(UserNotFoundException e)
		{
			System.out.println("User is not in Database");
		}
		catch(ProductNotFoundException e)
		{
			System.out.println("Product is not in Database");
		}
		
		return null;
		
	}
	@RequestMapping(value = "/user/{userId}", method = RequestMethod.PUT)
	public Cart removeAllProductIncart(@PathVariable int userId,@PathVariable int productId)
	{
		try {
		
				return cartService.removeAllProductTocart(userId);
			 
		}
		catch(UserNotFoundException e)
		{
			System.out.println("User is not in Database");
		}
		catch(ProductNotFoundException e)
		{
			System.out.println("Product is not in Database");
		}
		
		return null;
		
	}
	


}
