package com.mindtree.ShoppingCartRest.controller;



/**
 * @author M1053638
 *
 */

public class ErrorHandler {

}
