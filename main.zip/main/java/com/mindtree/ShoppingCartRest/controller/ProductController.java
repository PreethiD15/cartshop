package com.mindtree.ShoppingCartRest.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShoppingCartRest.entity.Product;
import com.mindtree.ShoppingCartRest.exception.CategoryNotFound;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.service.ProductService;

/**
 * @author M1053638
 *
 */
@RestController
@RequestMapping(value = "/product")
public class ProductController {
	@Autowired
	private ProductService productService;

	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	

	@RequestMapping(value = "search/name/{productName}", method = RequestMethod.GET)
	public Product searchByName(@PathVariable String productName) {
		try {
			return productService.searchByName(productName.toUpperCase());
		} catch (ProductNotFoundException e) {
			logger.error("Products Not Found");
			return null;
		} catch (Exception e) {
			logger.error("Error" + e);
			return null;
		}

	}

	@RequestMapping(value = "search/Id/{productId}", method = RequestMethod.GET)
	public Optional<Product> searchById(@PathVariable int productId) {
		try {
			return productService.searchById(productId);
		} catch (ProductNotFoundException e) {
			logger.error("Products Not Found");
			return null;
		} catch (Exception e) {
			logger.error("Error" + e);
			return null;
		}
	}

	
}

