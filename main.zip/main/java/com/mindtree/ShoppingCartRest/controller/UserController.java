package com.mindtree.ShoppingCartRest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShoppingCartRest.entity.User;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserAlreadyExist;
import com.mindtree.ShoppingCartRest.service.UserService;

import io.swagger.annotations.Api;

/**
 * @author M1053638 
 */
@RestController
@RequestMapping(value = "/user")
@Api(value = "Shopping Cart", description = "User CRUD Operation")
public class UserController {
	@Autowired
	private UserService userService;


	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public boolean addUser(@RequestBody User userdetail) {
		boolean flag = false;
		String success = null;
		try {
			success = userService.addUserToDb(userdetail);
			flag = true;
			return flag;
		} catch (UserAlreadyExist e) {
			logger.error("User Already Exist");
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		} finally {
			if (flag) {
				logger.info(success);
			}
		}
		return flag;

	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public List<User> displayAllUser() {
		List<User> list1 = null;
		try {
			list1 = userService.displayAllUsers();
		}

		catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		}
		return list1;
	}

	@RequestMapping(value = "/update/{userId}", method = RequestMethod.PUT)
	public User updateUser(@PathVariable int userId, @RequestBody User user) {
		try {
			return userService.updateUserDetail(userId, user);
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}
		return null;
	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public boolean deleteUser(int userId) {
		boolean flag = false;
		try {
			if (userService.deleteUserDetail(userId)) {
				flag = true;
			}
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error("Uncaught Exception");
		}

		return flag;
	}

}
