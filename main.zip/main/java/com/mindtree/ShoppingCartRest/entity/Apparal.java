package com.mindtree.ShoppingCartRest.entity;



import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import org.hibernate.validator.constraints.Length;

/**
 * @author M1053638
 *
 */

@Entity
@DiscriminatorValue("Apparal")

@NamedQuery(name = "Apparal.findByName", query = "FROM Apparal WHERE prod_name = ?1")
public class Apparal extends Product {
	

	@Column(name = "Type")
	@Length(min = 5, message = "*Type must have at least 5 characters")
	private String type;

	@Column(name = "Brand")
	@Length(min = 5, message = "*Brand must have at least 5 characters")
	private String brand;

	@Column(name = "Design")
	@Length(min = 5, message = "*Design must have at least 5 characters")
	private String design;

	/**
	 * constructor
	 */
	public Apparal() {
	
	}
	
	public Apparal(int product_Id,String prod_name, Integer quantity,float price) {
		super(product_Id, prod_name, quantity,price);
	}
	/**
	 * @param type
	 * @param brand
	 * @param design
	 */
	public Apparal(@Length(min = 5, message = "*Type must have at least 5 characters") String type,
			@Length(min = 5, message = "*Brand must have at least 5 characters") String brand,
			@Length(min = 5, message = "*Design must have at least 5 characters") String design) {
		super();
		this.type = type;
		this.brand = brand;
		this.design = design;
	}


	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the design
	 */
	public String getDesign() {
		return design;
	}

	/**
	 * @param design the design to set
	 */
	public void setDesign(String design) {
		this.design = design;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Apparal [type=" + type + ", brand=" + brand + ", design=" + design + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((design == null) ? 0 : design.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparal other = (Apparal) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (design == null) {
			if (other.design != null)
				return false;
		} else if (!design.equals(other.design))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	

}
