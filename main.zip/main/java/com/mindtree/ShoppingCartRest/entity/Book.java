package com.mindtree.ShoppingCartRest.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import org.hibernate.validator.constraints.Length;

/**
 * @author M1053638
 *
 */

@Entity
@DiscriminatorValue("Book")

@NamedQuery(name = "Book.findByName", query = "FROM Book WHERE prod_name = ?1")
public class Book extends Product {

	@Column(name = "genre")
	@Length(min = 5, message = "*Genre must have at least 5 characters")
	private String genre;
                                                                                                           
	@Column(name = "author_name")
	@Length(min = 5, message = "*Author must have at least 5 characters")
	private String author;

	@Column(name = "publication")
	@Length(min = 5, message = "*publication must have at least 5 characters")
	private String publication;

	/**
	 * Constructor
	 */
	public Book() {
		super();

	}

	public Book(int product_Id, String prod_name, Integer quantity, float price) {
		super(product_Id, prod_name, quantity, price);
	}

	/**
	 * @param genre
	 * @param author
	 * @param publication
	 */
	public Book(@Length(min = 5, message = "*Genre must have at least 5 characters") String genre,
			@Length(min = 5, message = "*Author must have at least 5 characters") String author,
			@Length(min = 5, message = "*publication must have at least 5 characters") String publication) {
		super();
		this.genre = genre;
		this.author = author;
		this.publication = publication;
	}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the publication
	 */
	public String getPublication() {
		return publication;
	}

	/**
	 * @param publication the publication to set
	 */
	public void setPublication(String publication) {
		this.publication = publication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Book [genre=" + genre + ", author=" + author + ", publication=" + publication + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((genre == null) ? 0 : genre.hashCode());
		result = prime * result + ((publication == null) ? 0 : publication.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (genre == null) {
			if (other.genre != null)
				return false;
		} else if (!genre.equals(other.genre))
			return false;
		if (publication == null) {
			if (other.publication != null)
				return false;
		} else if (!publication.equals(other.publication))
			return false;
		return true;
	}
	

}
