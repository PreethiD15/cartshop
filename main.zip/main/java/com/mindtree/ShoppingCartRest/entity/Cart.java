package com.mindtree.ShoppingCartRest.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * @author M1053638
 *
 */

@Entity
@Table(name = "Cart")
public class Cart {

	@Id
	@Column(name = "user_Id",  nullable = false)
	private int user_Id;
	@Column(name = "total_sum")
	private int total_sum;

	@OneToOne
	@JoinColumn(name = "user_Id")
	private User user;

	@OneToMany(fetch = FetchType.LAZY, cascade= {CascadeType.PERSIST, CascadeType.REMOVE})
	private List<ProductInCart> products;

	/**
	 * constructor
	 */
	public Cart() {
		super();
	}

	/**
	 * @param cart_Id
	 * @param total_sum
	 * @param user
	 * @param product
	 */
	public Cart(int user_Id, int total_sum, User user, List<ProductInCart> products) {
		super();
		this.user_Id = user_Id;
		this.total_sum = total_sum;
		this.user = user;
		this.products = products;
	}

// Getter and Setter

	/**
	 * @return the cart_Id
	 */
	public int getCart_Id() {
		return user_Id;
	}

	/**
	 * @param cart_Id the cart_Id to set
	 */
	public void setCart_Id(int user_Id) {
		this.user_Id = user_Id;
	}

	/**
	 * @return the total_sum
	 */
	public int getTotal_sum() {
		return total_sum;
	}

	/**
	 * @param total_sum the total_sum to set
	 */
	public void setTotal_sum(int total_sum) {
		this.total_sum = total_sum;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;

	}

	/**
	 * @return the product
	 */
	public List<ProductInCart> getProduct() {
		return products;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(List<ProductInCart> products) {
		this.products = products;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Cart [cart_Id=" + user_Id + ", total_sum=" + total_sum + ", user=" + user + ", product=" + products
				+ "]";
	}

}
