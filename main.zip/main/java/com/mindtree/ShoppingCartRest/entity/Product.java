package com.mindtree.ShoppingCartRest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.Length;

/**
 * @author M1053638
 *
 */

@Entity
@Inheritance(strategy=InheritanceType.JOINED) 
@Table(name = "product")


@NamedQuery(name = "Product.findByName", query = "FROM Product WHERE prod_name = ?1")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "product_Id", nullable = false)
	private int product_Id;

	@Column(name = "name", nullable = false, unique = true)
	@Length(min = 5, message = "*Name of the product must have at least 5 characters")
	private String prod_name;



	@Column(name = "quantity", nullable = false)
	@Min(value = 0, message = "*Quantity of the product has to be non negative number")
	private Integer quantity;

	@Column(name = "price", nullable = false)
	@Min(value = 0, message = "*Price of the product has to be non negative number")
	private float price;

	/**
	 * 
	 */
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param product_Id
	 * @param prod_name
	 * @param quantity
	 * @param price
	 */
	public Product(int product_Id,
			@Length(min = 5, message = "*Name of the product must have at least 5 characters") String prod_name,
			@Min(value = 0, message = "*Quantity of the product has to be non negative number") Integer quantity,
			@Min(value = 0, message = "*Price of the product has to be non negative number") float price) {
		super();
		this.product_Id = product_Id;
		this.prod_name = prod_name;
		this.quantity = quantity;
		this.price = price;
	}

	/**
	 * @return the product_Id
	 */
	public int getProduct_Id() {
		return product_Id;
	}

	/**
	 * @param product_Id the product_Id to set
	 */
	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	/**
	 * @return the prod_name
	 */
	public String getProd_name() {
		return prod_name;
	}

	/**
	 * @param prod_name the prod_name to set
	 */
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(price);
		result = prime * result + ((prod_name == null) ? 0 : prod_name.hashCode());
		result = prime * result + product_Id;
		result = prime * result + ((quantity == null) ? 0 : quantity.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		if (prod_name == null) {
			if (other.prod_name != null)
				return false;
		} else if (!prod_name.equals(other.prod_name))
			return false;
		if (product_Id != other.product_Id)
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		return true;
	}

	

}
