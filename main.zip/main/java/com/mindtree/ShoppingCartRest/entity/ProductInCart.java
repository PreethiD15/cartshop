package com.mindtree.ShoppingCartRest.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
@Entity
@IdClass(ProductInCartCompositeKey.class)
public class ProductInCart {


    @Id
	private int proId;
	private Integer quantityInCart;
	public ProductInCart() {
		super();
		
	}
	public ProductInCart(int proId, Integer quantityInCart) {
		super();
		this.proId = proId;
		this.quantityInCart = quantityInCart;
	}
	public int getProId() {
		return proId;
	}
	public void setProId(int proId) {
		this.proId = proId;
	}
	public Integer getQuantityInCart() {
		return quantityInCart;
	}
	public void setQuantityInCart(Integer quantityInCart) {
		this.quantityInCart = quantityInCart;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProductInCart [proId=" + proId + ", quantityInCart=" + quantityInCart + "]";
	}
	
	
}
