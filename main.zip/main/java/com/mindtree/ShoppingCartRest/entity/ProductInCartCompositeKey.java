package com.mindtree.ShoppingCartRest.entity;

import java.io.Serializable;

public class ProductInCartCompositeKey implements Serializable{

	   
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private int proId;
		private Integer quantityInCart;
		public ProductInCartCompositeKey() {
			super();
			// TODO Auto-generated constructor stub
		}
		/**
		 * @return the proId
		 */
		public int getProId() {
			return proId;
		}
		/**
		 * @param proId the proId to set
		 */
		public void setProId(int proId) {
			this.proId = proId;
		}
		/**
		 * @return the quantityInCart
		 */
		public Integer getQuantityInCart() {
			return quantityInCart;
		}
		/**
		 * @param quantityInCart the quantityInCart to set
		 */
		public void setQuantityInCart(Integer quantityInCart) {
			this.quantityInCart = quantityInCart;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + proId;
			result = prime * result + ((quantityInCart == null) ? 0 : quantityInCart.hashCode());
			return result;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			ProductInCartCompositeKey other = (ProductInCartCompositeKey) obj;
			if (proId != other.proId)
				return false;
			if (quantityInCart == null) {
				if (other.quantityInCart != null)
					return false;
			} else if (!quantityInCart.equals(other.quantityInCart))
				return false;
			return true;
		}
		
}
