package com.mindtree.ShoppingCartRest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

/**
 * @author M1053638
 *
 */

@Entity
@Table(name = "User")

@NamedQuery(name = "User.findByName", query = "FROM User WHERE user_Name = ?1")
public class User {
	// Entities of user
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_Id", nullable = false)
	private int user_Id;

	@Column(name = "user_Name", updatable = true, nullable = false)
	@Length(min = 5, message = "Name of the user must have at least 5 characters")
	private String user_Name;

	@Column(name = "user_MailId", updatable = true, nullable = false)
	@Length(min = 5, message = "MailId of the user must have at least 5 characters")
	private String user_MailId;

	@Column(name = "password", updatable = true, nullable = false)
	@Length(min = 5, message = "Password of the user must have at least 5 characters")
	private String password;

	@OneToOne(mappedBy = "user")
	private Cart cart;

// Constructor
	public User() {

	}

	/**
	 * @param user_Id
	 * @param user_Name
	 * @param user_MailId
	 * @param password
	 */
	public User(String user_Name, String user_MailId, String password) {
		super();

		this.user_Name = user_Name;
		this.user_MailId = user_MailId;
		this.password = password;
	}


	/**
	 * @return the user_Id
	 */
	public int getUser_Id() {
		return user_Id;
	}

	/**
	 * @param user_Id the user_Id to set
	 */
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}

	/**
	 * @return the user_Name
	 */
	public String getUser_Name() {
		return user_Name;
	}

	/**
	 * @param user_Name the user_Name to set
	 */
	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}

	/**
	 * @return the user_MailId
	 */
	public String getUser_MailId() {
		return user_MailId;
	}

	/**
	 * @param user_MailId the user_MailId to set
	 */
	public void setUser_MailId(String user_MailId) {
		this.user_MailId = user_MailId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [user_Id=" + user_Id + ", user_Name=" + user_Name + ", user_MailId=" + user_MailId + ", password="
				+ password + "]";
	}


}
