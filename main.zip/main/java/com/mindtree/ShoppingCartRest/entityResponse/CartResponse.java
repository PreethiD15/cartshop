package com.mindtree.ShoppingCartRest.entityResponse;

public class CartResponse {

	public CartResponse() {
		// TODO Auto-generated constructor stub
	}

}
