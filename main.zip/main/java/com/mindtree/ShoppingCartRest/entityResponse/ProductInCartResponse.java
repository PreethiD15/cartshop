package com.mindtree.ShoppingCartRest.entityResponse;

public class ProductInCartResponse {

	public ProductInCartResponse() {
		// TODO Auto-generated constructor stub
	}

}
