package com.mindtree.ShoppingCartRest.entityResponse;

public class UserResponse {

	public UserResponse() {
		// TODO Auto-generated constructor stub
	}

}
