package com.mindtree.ShoppingCartRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.ShoppingCartRest.entity.Apparal;



/**
 * @author M1053638
 *
 */

@Repository
public interface ApparalRepository extends JpaRepository<Apparal, Integer>{

	Apparal findByName(String prod_name);

}
