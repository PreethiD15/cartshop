package com.mindtree.ShoppingCartRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.ShoppingCartRest.entity.Book;


/**
 * @author M1053638
 *
 */

@Repository
public interface BookRepository extends JpaRepository<Book, Integer>  {

	Book findByName(String prod_name);

}
