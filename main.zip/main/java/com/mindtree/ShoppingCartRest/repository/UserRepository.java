package com.mindtree.ShoppingCartRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.ShoppingCartRest.entity.User;

/**
 * @author M1053638
 *
 */

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

User findByName(String user_Name);
}
