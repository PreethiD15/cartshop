package com.mindtree.ShoppingCartRest.service;

import com.mindtree.ShoppingCartRest.entity.Cart;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserNotFoundException;


/**
 * @author M1053638
 *
 */

public interface CartService {
    /*Add products to Cart in the Database if it a new product add it  or if it existing product increment by 1*/
	String addProductTocart(int userId, int productId) throws UserNotFoundException, ProductNotFoundException;

	/* Remove the product from the cart based on the quantity or if quantity is 1 remove the Product from the Product List of the Cart
	 * Update the product quantity and save in the Database */
	Cart removeProductTocart(int userId, int productId, int quantityId) throws UserNotFoundException, ProductNotFoundException, ResourceNotFoundException;

	/* Remove all the products from the Database */
	Cart removeAllProductTocart(int userId) throws UserNotFoundException, ProductNotFoundException;


}
