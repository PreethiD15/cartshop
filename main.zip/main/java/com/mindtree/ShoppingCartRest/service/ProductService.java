package com.mindtree.ShoppingCartRest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.mindtree.ShoppingCartRest.entity.Apparal;
import com.mindtree.ShoppingCartRest.entity.Book;
import com.mindtree.ShoppingCartRest.entity.Product;
import com.mindtree.ShoppingCartRest.exception.ApparalAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.BookAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.CategoryNotFound;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;

/**
 * @author M1053638
 *
 */

@Repository
public interface ProductService {
	/* Add the Apparal detail to the Database */
	String addApparalToDb(Apparal apparaldetail) throws ApparalAlreadyExist;

	/* Display all the Apparal in the database */
	List<Apparal> displayAllApparals() throws ResourceNotFoundException;

	/* update the Apparal Detail with Apparal Id in the Database */
	Apparal updateApparalDetail(int apparalId, Apparal apparal) throws ResourceNotFoundException;

	/* Delete the Apparal detail with ApparalId in the Database */
	boolean deleteApparalDetail(int apparalId) throws ResourceNotFoundException;

	/* Display all the Book in the database */
	List<Book> displayAllBooks() throws ResourceNotFoundException;

	/* update the book Detail with Book Id in the Database */
	Book updateBookDetail(int bookId, Book book) throws ResourceNotFoundException;

	/* Delete the Book detail with BookId in the Database */
	boolean deleteBookDetail(int bookId) throws ResourceNotFoundException;

	/* Add the Book detail to the Database */
	String addBookToDb(Book bookdetail) throws BookAlreadyExist;

	/* Search Product by Name in the Database */
	public Product searchByName(String productName) throws Exception, ProductNotFoundException;

	/* Search Product by Id in the Database */
	public Optional<Product> searchById(int productId) throws Exception, ProductNotFoundException;

}
