package com.mindtree.ShoppingCartRest.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.mindtree.ShoppingCartRest.entity.User;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserAlreadyExist;

public interface UserService {

	/* Add user to Database with User details */
	public String addUserToDb(@RequestBody User user) throws Exception, UserAlreadyExist;

	/* Display All the User in Database */
	public List<User> displayAllUsers() throws ResourceNotFoundException;

	/* Update  the user detail with userId  in the Database */
	public User updateUserDetail(int userId, User user) throws ResourceNotFoundException;

	/* delete the user detail with userId in the Database */
	public boolean deleteUserDetail(int userId) throws ResourceNotFoundException;

}
