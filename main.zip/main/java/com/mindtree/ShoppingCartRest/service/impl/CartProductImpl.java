package com.mindtree.ShoppingCartRest.service.impl;

public class CartProductImpl {

	public CartProductImpl() {
		// TODO Auto-generated constructor stub
	}

}
