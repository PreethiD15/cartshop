package com.mindtree.ShoppingCartRest.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.ShoppingCartRest.entity.Apparal;
import com.mindtree.ShoppingCartRest.entity.Book;
import com.mindtree.ShoppingCartRest.entity.Cart;
import com.mindtree.ShoppingCartRest.entity.Product;
import com.mindtree.ShoppingCartRest.entity.ProductInCart;
import com.mindtree.ShoppingCartRest.entity.User;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserNotFoundException;
import com.mindtree.ShoppingCartRest.repository.CartRepository;
import com.mindtree.ShoppingCartRest.repository.ProductInCartRepository;
import com.mindtree.ShoppingCartRest.repository.ProductRepository;
import com.mindtree.ShoppingCartRest.repository.UserRepository;
import com.mindtree.ShoppingCartRest.service.CartService;

/**
 * @author M1053638
 *
 */
/**
 * @author M1053638
 *
 */
@Service
@Transactional
public class CartServiceImpl implements CartService {
	private Map<Integer, Integer>productList = new HashMap<>();

	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private ProductInCartRepository productInCartRepository;

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private UserRepository userRepository;
    int useridfinal=0;

    /*
     * (non-Javadoc)
     * @see com.mindtree.ShoppingCartRest.service.CartService#addProductTocart(int, int)
     * Add Product to Cart based on the User Id and the Product Id 
     * It is increment by ! if the product is added newly to the cart
     * 
     */
	@Override
	public String addProductTocart(int userId, int productId) throws UserNotFoundException, ProductNotFoundException {
         
		if (!userRepository.existsById(userId)) {
			throw new UserNotFoundException("UserId " + userId + " not found");
		} else {
			if (!productRepository.existsById(productId)) {
				throw new ProductNotFoundException("ProductId " + productId + " not found");
			} else {
				Optional<Product> productfound = productRepository.findById(productId);
				Product producttocart = productfound.get();
				if (producttocart instanceof Apparal) {
					addApparalProduct((Apparal) producttocart);
					System.out.println(productList);

				} else {
					addBookProduct((Book) producttocart);
					System.out.println(productList);

				}
				Optional<User> user = userRepository.findById(userId);
				User usercart = user.get();
				if(useridfinal!=usercart.getUser_Id())
				{
				 useridfinal=usercart.getUser_Id();
				productList.clear();
				 productInCartRepository.deleteAll();
				 
				}
				else
				{
				int amount = (int) getProductsInCart();
				System.out.println(amount);
				List<ProductInCart> productincart = productList();
				System.out.println(productincart);
				
				System.out.println(usercart);
				Cart cartfinal = new Cart(usercart.getUser_Id(), amount, usercart, productincart);
				System.out.println(cartfinal);
				cartRepository.save(cartfinal);
				}
			}
		}
	
		return null;

	}
/* Add book to the Cart of the Product List */
	private void addBookProduct(Book book) {
		int product_Id = book.getProduct_Id();

		if (productList.containsKey(product_Id)) {

			productList.replace(product_Id,productList.get(book.getProduct_Id()) + 1);
		} else {
			productList.put(product_Id, 1);
		}

	}

	/* Add apparal to the Cart of the Product List */
	private void addApparalProduct(Apparal apparal) {
		int product_Id = apparal.getProduct_Id();

		if (productList.containsKey(product_Id)) {

			productList.replace(product_Id,productList.get(apparal.getProduct_Id()) + 1);
		} else {
			productList.put(product_Id, 1);
		}

	}

	/* List the Product in the Cart and find the amount */
	public float getProductsInCart() {

		System.out.println("getProductInCart");

		for (Map.Entry<Integer, Integer> product :productList.entrySet()) {

			ProductInCart productInCart = new ProductInCart(product.getKey(), product.getValue());
			productInCartRepository.save(productInCart);
		}

		return findAmount();
	}

	public List<ProductInCart> productList() {
		List<ProductInCart> productslist = new ArrayList<>();
		for (Map.Entry<Integer, Integer> product :productList.entrySet()) {

			ProductInCart productInCart = new ProductInCart(product.getKey(), product.getValue());
			productslist.add(productInCart);
		}
		System.out.println(productslist);
		return productslist;
	}

	/* Find the Cost of the Product in the Product List */
	public float findAmount() {
		float totalamount = 0;
		float amount = 0;

		for (Map.Entry<Integer, Integer> product :productList.entrySet()) {
			Optional<Product> productinList = productRepository.findById(product.getKey());
			Product productList = productinList.get();
			amount = productList.getPrice() * product.getValue();
			totalamount += amount;
		}

		System.out.println(totalamount);
		return totalamount;

	}
   /* Remove the Product in the Cart and update the cart*/
	@Override
	public Cart removeProductTocart(int userId, int productId, int quantityId) throws UserNotFoundException, ProductNotFoundException, ResourceNotFoundException {
		if (!userRepository.existsById(userId)) {
			throw new UserNotFoundException("UserId " + userId + " not found");
		} else {
			if (!productRepository.existsById(productId)) {
				throw new ProductNotFoundException("ProductId " + productId + " not found");
			}
			else {
				
				Optional<Cart> cart=cartRepository.findById(userId);
				Cart cartobj=cart.get();
				System.out.println(cartobj);
				List<ProductInCart> productincart =cartobj.getProduct();
				System.out.println(productincart);
				for (ProductInCart product:productincart)
				{
					if(product.getProId()==productId)
					{
						int quantity=product.getQuantityInCart();
						if(quantity>0 && quantity>quantityId)
						{
							int changequantity=quantity-quantityId;
							product.setQuantityInCart(changequantity);
						}
					}
				}
			
				for (ProductInCart product:productincart)
				{
				ProductInCart productInCart = new ProductInCart(product.getProId(), product.getQuantityInCart());
				productInCartRepository.save(productInCart);
				}
				float totalreducedamount=findReduceAmount(productincart);
				
				
				if (!cartRepository.existsById(userId)) {
					throw new ResourceNotFoundException("cartId " + userId + " not found");
				}
				 
				return cartRepository.findById(userId).map(updatecart-> {
					
					updatecart.setCart_Id(cartobj.getCart_Id());
					updatecart.setTotal_sum((int) totalreducedamount);
					updatecart.setProduct(productincart);
					updatecart.setUser(cartobj.getUser());
					return cartRepository.save(updatecart);
				}).orElseThrow(() -> new ResourceNotFoundException("CartId " + userId + " not found"));
			
			
				
			}
		}
	}
    /* find the total after the updated Cart */
	private float findReduceAmount(List<ProductInCart> productincart) {
		System.out.println(productincart);
		float totalamount = 0;
		float amount = 0;
		for (ProductInCart product:productincart)
		{
			Optional<Product> productinList = productRepository.findById(product.getProId());
			Product productList = productinList.get();
			amount = productList.getPrice() * product.getQuantityInCart();
			totalamount += amount;
			
		}
		System.out.println(totalamount);
		return totalamount;
	}

	/* remove all the Product in the Cart with the User Id */
	@Override
	public Cart removeAllProductTocart(int userId) throws UserNotFoundException, ProductNotFoundException {
		if (!userRepository.existsById(userId)) {
			throw new UserNotFoundException("UserId " + userId + " not found");
		} else {
			
				Optional<Cart> cart=cartRepository.findById(userId);
				Cart cartobj=cart.get();
				System.out.println(cartobj);
				cartRepository.deleteById(cartobj.getCart_Id());
			
		}
		return null;
	}

}

