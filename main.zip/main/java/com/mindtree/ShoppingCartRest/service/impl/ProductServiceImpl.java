package com.mindtree.ShoppingCartRest.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ShoppingCartRest.entity.Apparal;
import com.mindtree.ShoppingCartRest.entity.Book;
import com.mindtree.ShoppingCartRest.entity.Product;
import com.mindtree.ShoppingCartRest.exception.ApparalAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.BookAlreadyExist;
import com.mindtree.ShoppingCartRest.exception.ProductNotFoundException;
import com.mindtree.ShoppingCartRest.repository.ApparalRepository;
import com.mindtree.ShoppingCartRest.repository.BookRepository;
import com.mindtree.ShoppingCartRest.repository.ProductRepository;
import com.mindtree.ShoppingCartRest.service.ProductService;

/**
 * @author M1053638
 *
 */
@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private ApparalRepository apparalRepository;
	@Autowired
	private ProductRepository productRepository;


	/* Add the Apparal detail to the Database */
	@Override
	public String addApparalToDb(Apparal apparaldetail) throws ApparalAlreadyExist {
		Apparal apparalresult = apparalRepository.findByName(apparaldetail.getProd_name());
		if (apparalresult == null) {

			apparalRepository.save(apparaldetail);
		} else {
			throw new ApparalAlreadyExist("Apparal Already Exist in Database...");
		}

		return "Apparal Added Successfully";

	}


	/* Display all the Apparal in the database */
	@Override
	public List<Apparal> displayAllApparals() throws ResourceNotFoundException {
		List<Apparal> apparalList = null;
		try {
			apparalList = apparalRepository.findAll();

		} catch (Exception e) {
			throw new ResourceNotFoundException("Resource not found", e);
		}
		return apparalList;

	}


	/* update the Apparal Detail with Apparal Id in the Database */
	@Override
	public Apparal updateApparalDetail(int productId, Apparal apparal) throws ResourceNotFoundException {
		if (!apparalRepository.existsById(productId)) {
			throw new ResourceNotFoundException("ApparalId " + productId + " not found");
		}

		return apparalRepository.findById(productId).map(updateapparal -> {
			updateapparal.setBrand(apparal.getBrand());
			updateapparal.setDesign(apparal.getDesign());
			updateapparal.setType(apparal.getType());
			return apparalRepository.save(updateapparal);
		}).orElseThrow(() -> new ResourceNotFoundException("ApparalId " + productId + " not found"));
	}


	/* Delete the Apparal detail with ApparalId in the Database */
	@Override
	public boolean deleteApparalDetail(int productId) throws ResourceNotFoundException {
		boolean flag = false;
		if (!apparalRepository.existsById(productId)) {
			throw new ResourceNotFoundException("ApparalId " + productId + " not found");
		} else {
			apparalRepository.deleteById(productId);
			flag = true;

		}
		return flag;
	}


	/* Display all the Book in the database */
	@Override
	public List<Book> displayAllBooks() throws ResourceNotFoundException {

		List<Book> bookList = null;
		try {
			bookList = bookRepository.findAll();

		} catch (Exception e) {
			throw new ResourceNotFoundException("Resource not found", e);
		}
		return bookList;
	}


	/* update the book Detail with Book Id in the Database */
	@Override
	public Book updateBookDetail(int bookId, Book book) throws ResourceNotFoundException {
		if (!bookRepository.existsById(bookId)) {
			throw new ResourceNotFoundException("BookId " + bookId + " not found");
		}

		return bookRepository.findById(bookId).map(updatebook -> {
			updatebook.setAuthor(book.getAuthor());
			updatebook.setGenre(book.getGenre());
			updatebook.setPublication(book.getPublication());
			return bookRepository.save(updatebook);
		}).orElseThrow(() -> new ResourceNotFoundException("BookId " + bookId + " not found"));
	}


	/* Delete the Book detail with BookId in the Database */
	@Override
	public boolean deleteBookDetail(int bookId) throws ResourceNotFoundException {
		boolean flag = false;
		if (!bookRepository.existsById(bookId)) {
			throw new ResourceNotFoundException("BookId " + bookId + " not found");
		} else {
			bookRepository.deleteById(bookId);
			flag = true;

		}
		return flag;

	}


	/* Add the Book detail to the Database */
	@Override
	public String addBookToDb(Book bookdetail) throws BookAlreadyExist {
		Book result = bookRepository.findByName(bookdetail.getProd_name());
		if (result == null) {

			bookRepository.save(bookdetail);
		} else {
			throw new BookAlreadyExist("Book Already Exist in Database...");
		}

		return "Book Added Successfully";
	}
	

	/* Search Product by Name in the Database */
	public Product searchByName(String productname) throws Exception, ProductNotFoundException {
		try {
			if (productRepository.findByName(productname) != null) {
				return productRepository.findByName(productname);
			} else {
				throw new ProductNotFoundException("Product not found");
			}
		} catch (ProductNotFoundException e) {
			throw new ProductNotFoundException();
		} catch (Exception e) {
			throw new Exception();
		}
	}


	/* Search Product by Id in the Database */
	public Optional<Product> searchById(int productId) throws Exception, ProductNotFoundException {
		try {
			if (productRepository.existsById(productId)) {
				return productRepository.findById(productId);
			} else {
				throw new ProductNotFoundException();
			}
		} catch (ProductNotFoundException e) {
			throw new ProductNotFoundException();
		} catch (Exception e) {
			throw new Exception();
		}
	}

	

}
