package com.mindtree.ShoppingCartRest.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.mindtree.ShoppingCartRest.entity.User;
import com.mindtree.ShoppingCartRest.exception.ResourceNotFoundException;
import com.mindtree.ShoppingCartRest.exception.UserAlreadyExist;
import com.mindtree.ShoppingCartRest.repository.UserRepository;
import com.mindtree.ShoppingCartRest.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
  /* Add user to Database */
	@Override
	public String addUserToDb(@RequestBody User user) throws Exception, UserAlreadyExist {
		User result = userRepository.findByName(user.getUser_Name());
		if (result == null) {

			userRepository.save(user);
		} else {
			throw new UserAlreadyExist("User Already Exist in Database...");
		}


		return "User Added Successfully";

	}

	/* Display All the User in Database*/
	@Override
	public List<User> displayAllUsers() throws ResourceNotFoundException {
		List<User> userList=null;
		try {
		userList=userRepository.findAll();
		
		}
		catch(Exception e)
		{
			throw new ResourceNotFoundException ("Resource not found",e);
		}
		return userList;
	}

	/* Update all the user in the Database */
	@Override
	public User updateUserDetail(int userId,User user) throws ResourceNotFoundException{
		
		 if(!userRepository.existsById(userId)) {
	            throw new ResourceNotFoundException("UserId " + userId+ " not found");
	        }
		
	       return userRepository.findById(userId).map(updateuser -> {
	        	updateuser.setUser_Name(user.getUser_Name());
	        	updateuser.setUser_MailId(user.getUser_MailId());
	        	updateuser.setPassword(user.getPassword());
	            return userRepository.save(updateuser);
	        }).orElseThrow(() -> new ResourceNotFoundException("UserId " + userId+ " not found"));
		}

	/*delete the user in the Database*/
	@Override
	public boolean deleteUserDetail(int userId) throws ResourceNotFoundException {
		boolean flag=false;
		 if(!userRepository.existsById(userId)) {
	            throw new ResourceNotFoundException("UserId " + userId+ " not found");
	        }
		 else {
			 userRepository.deleteById(userId);
			 flag=true;
			
		 }
		 return flag; 
		
	}
	   
		
		
		
	
}
